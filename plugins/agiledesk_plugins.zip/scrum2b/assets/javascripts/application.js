//= require jquery
//= require jquery_ujs
//= require jquery-ui
//= require jquery.ui.slider.
