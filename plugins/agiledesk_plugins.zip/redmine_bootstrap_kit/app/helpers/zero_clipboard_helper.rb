module ZeroClipboardHelper
  include AssetsLoaderBase
  include ZeroClipboard::AssetsLoader
  include ZeroClipboard::ZeroClipboardHelper
end
