module CodeMirrorHelper
  include AssetsLoaderBase
  include CodeMirror::AssetsLoader
  include CodeMirror::ColorizerHelper
end
