module JqueryFileTreeHelper
  include AssetsLoaderBase
  include JqueryFileTree::AssetsLoader
  include JqueryFileTree::DocTreeHelper
end
