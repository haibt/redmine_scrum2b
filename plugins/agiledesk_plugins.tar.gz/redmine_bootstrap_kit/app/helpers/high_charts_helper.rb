module HighChartsHelper
  include AssetsLoaderBase
  include HighCharts::AssetsLoader
end
